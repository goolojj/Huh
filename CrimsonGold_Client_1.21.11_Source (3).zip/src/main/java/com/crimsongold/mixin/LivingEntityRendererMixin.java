package com.crimsongold.mixin;

import com.crimsongold.CrimsonGoldClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin<T extends LivingEntity> {
    @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void onHasLabel(T entity, double squaredDistanceToCamera, CallbackInfoReturnable<Boolean> cir) {
        if (CrimsonGoldClient.CONFIG != null && CrimsonGoldClient.CONFIG.showSelfNametag) {
            if (entity == MinecraftClient.getInstance().player) {
                cir.setReturnValue(true);
            }
        }
    }
}
