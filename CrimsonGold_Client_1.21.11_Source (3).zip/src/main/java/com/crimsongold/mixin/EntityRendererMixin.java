package com.crimsongold.mixin;

import com.crimsongold.CrimsonGoldClient;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class EntityRendererMixin<T extends Entity> {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void onGetDisplayName(T entity, CallbackInfoReturnable<Text> cir) {
        if (CrimsonGoldClient.CONFIG != null && CrimsonGoldClient.CONFIG.nametagCrownEnabled) {
            if (entity instanceof PlayerEntity && cir.getReturnValue() != null) {
                cir.setReturnValue(Text.literal("§c§l[§6♛§c§l] §r").append(cir.getReturnValue()));
            }
        }
    }
}
