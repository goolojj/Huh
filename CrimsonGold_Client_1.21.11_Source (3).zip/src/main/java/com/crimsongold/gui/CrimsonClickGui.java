package com.crimsongold.gui;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

public class CrimsonClickGui extends Screen {
    private enum Tab { HOME, PVP, FPS, HUD }

    private record ModCard(String name, String desc, Tab tab, BooleanSupplier getter, Runnable toggler, int x, int y, int w, int h) {}

    private Tab activeTab = Tab.HOME;
    private int page = 0;
    private int totalPages = 1;
    private final List<ModCard> visibleCards = new ArrayList<>();
    private final List<int[]> tabBounds = new ArrayList<>();
    private final List<int[]> presetBounds = new ArrayList<>();

    private int winX, winY, winW, winH;
    private int closeX, closeY, closeW, closeH;
    private int prevX, prevY, nextX, nextY, navW = 46, navH = 15;

    public CrimsonClickGui() {
        super(Text.literal("Crimson Client"));
    }

    @Override
    protected void init() {
        visibleCards.clear();
        tabBounds.clear();
        presetBounds.clear();

        winW = Math.min(410, this.width - 32);
        winH = Math.min(230, this.height - 24);
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        ClientConfig cfg = CrimsonGoldClient.CONFIG;
        int sideW = 88;

        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            int tx = winX + 8;
            int ty = winY + 34 + i * 24;
            int tw = sideW - 16;
            int th = 20;
            tabBounds.add(new int[]{tx, ty, tw, th});
            Tab t = tabs[i];
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
                activeTab = t;
                page = 0;
                this.clearAndInit();
            }).dimensions(tx, ty, tw, th).build());
        }

        closeX = winX + 8;
        closeY = winY + winH - 25;
        closeW = sideW - 16;
        closeH = 17;
        this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            cfg.save();
            this.close();
        }).dimensions(closeX, closeY, closeW, closeH).build());

        int contentX = winX + sideW + 8;
        int contentW = winW - sideW - 16;

        if (activeTab == Tab.HOME) {
            int presetY = winY + 72;
            int pw = (contentW - 12) / 3;
            for (int p = 1; p <= 3; p++) {
                int px = contentX + (p - 1) * (pw + 6);
                int presetVal = p;
                presetBounds.add(new int[]{px, presetY, pw, 18, presetVal});
                this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
                    CrimsonGoldClient.applyFpsPreset(MinecraftClient.getInstance(), presetVal);
                }).dimensions(px, presetY, pw, 18).build());
            }
        }

        // 24 Rich Modules across HOME / PVP / FPS / HUD
        List<ModCard> all = new ArrayList<>();
        // HOME (6)
        all.add(new ModCard("Crown Nametag", "Show ♛ Badge", Tab.HOME, () -> cfg.nametagCrownEnabled, () -> { cfg.nametagCrownEnabled = !cfg.nametagCrownEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Self Nametag", "Visible in F5", Tab.HOME, () -> cfg.showSelfNametag, () -> { cfg.showSelfNametag = !cfg.showSelfNametag; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("FPS Boost All", "Max Mobile FPS", Tab.HOME, () -> cfg.fpsBoostEnabled, () -> { cfg.fpsBoostEnabled = !cfg.fpsBoostEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("ToggleSprint", "Auto Sprint", Tab.HOME, () -> cfg.toggleSprintEnabled, () -> { cfg.toggleSprintEnabled = !cfg.toggleSprintEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Pro Armor HUD", "Gear + Durability", Tab.HOME, () -> cfg.armorHudEnabled, () -> { cfg.armorHudEnabled = !cfg.armorHudEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Entity Outline", "Glow Targets", Tab.HOME, () -> cfg.outlineEnabled, () -> { cfg.outlineEnabled = !cfg.outlineEnabled; cfg.save(); }, 0, 0, 0, 0));

        // PVP (8)
        all.add(new ModCard("Crown Nametag", "Show ♛ on Tags", Tab.PVP, () -> cfg.nametagCrownEnabled, () -> { cfg.nametagCrownEnabled = !cfg.nametagCrownEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Self Nametag", "Show Own Tag", Tab.PVP, () -> cfg.showSelfNametag, () -> { cfg.showSelfNametag = !cfg.showSelfNametag; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Mini Target Pill", "Enemy HP & Dist", Tab.PVP, () -> cfg.hitboxEnabled, () -> { cfg.hitboxEnabled = !cfg.hitboxEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Reach Display", "Last Hit Meters", Tab.PVP, () -> cfg.reachDisplayEnabled, () -> { cfg.reachDisplayEnabled = !cfg.reachDisplayEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Entity Outline", "Glow Targets <32m", Tab.PVP, () -> cfg.outlineEnabled, () -> { cfg.outlineEnabled = !cfg.outlineEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("ToggleSprint", "Auto Sprint", Tab.PVP, () -> cfg.toggleSprintEnabled, () -> { cfg.toggleSprintEnabled = !cfg.toggleSprintEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("ToggleSneak", "Auto Crouch", Tab.PVP, () -> cfg.toggleSneakEnabled, () -> { cfg.toggleSneakEnabled = !cfg.toggleSneakEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("NoHurtCam", "Zero Hit Shake", Tab.PVP, () -> cfg.noHurtCamEnabled, () -> { cfg.noHurtCamEnabled = !cfg.noHurtCamEnabled; cfg.save(); }, 0, 0, 0, 0));

        // FPS (8)
        all.add(new ModCard("FPS Boost All", "Enable All Tweaks", Tab.FPS, () -> cfg.fpsBoostEnabled, () -> { cfg.fpsBoostEnabled = !cfg.fpsBoostEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("No Shadows", "Hide Drop Shadow", Tab.FPS, () -> cfg.noShadowsEnabled, () -> { cfg.noShadowsEnabled = !cfg.noShadowsEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("No Bobbing", "Steady Camera", Tab.FPS, () -> cfg.noBobbingEnabled, () -> { cfg.noBobbingEnabled = !cfg.noBobbingEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Fast Chunks", "0 Biome Blend", Tab.FPS, () -> cfg.zeroBiomeBlendEnabled, () -> { cfg.zeroBiomeBlendEnabled = !cfg.zeroBiomeBlendEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("0 Mipmaps", "GPU Texture Boost", Tab.FPS, () -> cfg.zeroMipmapsEnabled, () -> { cfg.zeroMipmapsEnabled = !cfg.zeroMipmapsEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("50% Entity Dist", "Cull Far Entities", Tab.FPS, () -> cfg.lowEntityDistEnabled, () -> { cfg.lowEntityDistEnabled = !cfg.lowEntityDistEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Fullbright", "Max Cave Light", Tab.FPS, () -> cfg.fullbrightEnabled, () -> { cfg.fullbrightEnabled = !cfg.fullbrightEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Motion Blur", "Turn Speed Blur", Tab.FPS, () -> cfg.motionBlurEnabled, () -> { cfg.motionBlurEnabled = !cfg.motionBlurEnabled; cfg.save(); }, 0, 0, 0, 0));

        // HUD (7)
        all.add(new ModCard("Pro Armor HUD", "Glass Card + %", Tab.HUD, () -> cfg.armorHudEnabled, () -> { cfg.armorHudEnabled = !cfg.armorHudEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Keystrokes", "WASD + Space", Tab.HUD, () -> cfg.keystrokesEnabled, () -> { cfg.keystrokesEnabled = !cfg.keystrokesEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("FPS & Info", "FPS / XYZ / CPS", Tab.HUD, () -> cfg.cpsCounterEnabled, () -> { cfg.cpsCounterEnabled = !cfg.cpsCounterEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Crimson Aim+", "Crosshair Dot", Tab.HUD, () -> cfg.crosshairEnabled, () -> { cfg.crosshairEnabled = !cfg.crosshairEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Sprint Pill", "Bottom Badge", Tab.HUD, () -> cfg.sprintPillEnabled, () -> { cfg.sprintPillEnabled = !cfg.sprintPillEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Ping & Clock", "Top-Right Pill", Tab.HUD, () -> cfg.pingTimePillEnabled, () -> { cfg.pingTimePillEnabled = !cfg.pingTimePillEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModCard("Master HUD", "All Overlays", Tab.HUD, () -> cfg.hudEnabled, () -> { cfg.hudEnabled = !cfg.hudEnabled; cfg.save(); }, 0, 0, 0, 0));

        List<ModCard> filtered = new ArrayList<>();
        for (ModCard m : all) {
            if (m.tab() == activeTab) filtered.add(m);
        }

        int gridY = (activeTab == Tab.HOME) ? (winY + 96) : (winY + 34);
        int perPage = (activeTab == Tab.HOME) ? 6 : 8;
        totalPages = Math.max(1, (int) Math.ceil(filtered.size() / (double) perPage));
        if (page >= totalPages) page = totalPages - 1;

        int cardW = (contentW - 6) / 2;
        int cardH = (activeTab == Tab.HOME) ? 31 : 34;

        int start = page * perPage;
        int end = Math.min(filtered.size(), start + perPage);
        for (int i = start; i < end; i++) {
            int local = i - start;
            int col = local % 2;
            int row = local / 2;
            int cx = contentX + col * (cardW + 6);
            int cy = gridY + row * (cardH + 5);
            ModCard m = filtered.get(i);
            ModCard placed = new ModCard(m.name(), m.desc(), m.tab(), m.getter(), m.toggler(), cx, cy, cardW, cardH);
            visibleCards.add(placed);
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> placed.toggler().run())
                    .dimensions(cx, cy, cardW, cardH).build());
        }

        prevX = contentX;
        prevY = winY + winH - 22;
        nextX = winX + winW - navW - 8;
        nextY = prevY;
        if (totalPages > 1) {
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
                if (page > 0) { page--; this.clearAndInit(); }
            }).dimensions(prevX, prevY, navW, navH).build());
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
                if (page < totalPages - 1) { page++; this.clearAndInit(); }
            }).dimensions(nextX, nextY, navW, navH).build());
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        // Translucent backdrop so world shows softly behind frosted glass
        ctx.fill(0, 0, this.width, this.height, 0x55040206);

        // Frosted Glass Window (translucent gradient + specular top edge)
        drawRoundedBox(ctx, winX - 2, winY + 2, winW + 4, winH + 2, 0x55000000);
        drawRoundedBox(ctx, winX, winY, winW, winH, 0xB80E080E);
        ctx.fillGradient(winX + 2, winY + 2, winX + winW - 2, winY + winH - 2, 0x44360B18, 0x4408060A);
        drawRoundedOutline(ctx, winX, winY, winW, winH, 0xCCE51A3C);
        ctx.fill(winX + 4, winY + 1, winX + winW - 4, winY + 2, 0x66FFFFFF); // Glass specular highlight

        // Header Bar
        ctx.fillGradient(winX + 2, winY + 2, winX + winW - 2, winY + 26, 0xBB260A14, 0x9912070C);
        ctx.fill(winX + 2, winY + 26, winX + winW - 2, winY + 27, 0xAAE51A3C);
        drawMiniCrown(ctx, winX + 10, winY + 9);
        ctx.drawTextWithShadow(this.textRenderer, "§c§lCRIMSON §f§lCLIENT", winX + 25, winY + 10, 0xFFFFFFFF);
        String ver = "§71.21.11  •  §6♛ v3.0 GLASS";
        ctx.drawTextWithShadow(this.textRenderer, ver, winX + winW - this.textRenderer.getWidth(ver) - 10, winY + 10, 0xFFFFFFFF);

        // Sidebar Glass Divider
        int sideW = 88;
        ctx.fill(winX + sideW, winY + 28, winX + sideW + 1, winY + winH - 4, 0x33FFFFFF);

        // Sidebar Tabs
        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            int[] b = tabBounds.get(i);
            boolean active = (tabs[i] == activeTab);
            boolean hov = isHover(mouseX, mouseY, b[0], b[1], b[2], b[3]);
            int bg = active ? 0xCCE51A3C : (hov ? 0x8832121D : 0x5518121A);
            drawRoundedBox(ctx, b[0], b[1], b[2], b[3], bg);
            if (active) {
                drawRoundedOutline(ctx, b[0], b[1], b[2], b[3], 0xFFFFD466);
                ctx.fill(b[0] + 2, b[1] + 1, b[0] + b[2] - 2, b[1] + 2, 0x55FFFFFF);
            }
            String label = tabs[i].name();
            int tw = this.textRenderer.getWidth(label);
            ctx.drawTextWithShadow(this.textRenderer, label, b[0] + (b[2] - tw) / 2, b[1] + 6, active ? 0xFFFFFFFF : 0xFFDDDDDD);
        }

        // Player Profile Glass Card
        String ign = (mc.player != null) ? mc.player.getName().getString() : "Player";
        if (ign.length() > 10) ign = ign.substring(0, 10);
        int profY = winY + winH - 64;
        drawRoundedBox(ctx, winX + 8, profY, sideW - 16, 32, 0x771A0D14);
        drawRoundedOutline(ctx, winX + 8, profY, sideW - 16, 32, 0x66E51A3C);
        ctx.drawTextWithShadow(this.textRenderer, "§f" + ign, winX + 13, profY + 5, 0xFFFFFFFF);
        ctx.drawText(this.textRenderer, "§a● §6♛ VIP", winX + 13, profY + 18, 0xFFFFD466, false);

        // Close Button
        boolean closeHov = isHover(mouseX, mouseY, closeX, closeY, closeW, closeH);
        drawRoundedBox(ctx, closeX, closeY, closeW, closeH, closeHov ? 0xDDE51A3C : 0x997A1124);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "Close", closeX + closeW / 2, closeY + 5, 0xFFFFFFFF);

        // HOME Dashboard Banner + FPS Presets
        if (activeTab == Tab.HOME) {
            int contentX = winX + sideW + 8;
            int contentW = winW - sideW - 16;
            drawRoundedBox(ctx, contentX, winY + 33, contentW, 33, 0x88200B14);
            drawRoundedOutline(ctx, contentX, winY + 33, contentW, 33, 0x88E51A3C);
            ctx.fill(contentX + 2, winY + 34, contentX + contentW - 2, winY + 35, 0x44FFFFFF);
            ctx.drawTextWithShadow(this.textRenderer, "§c§lFPS TUNING §f• §a" + mc.getCurrentFps() + " FPS", contentX + 8, winY + 39, 0xFFFFFFFF);
            ctx.drawText(this.textRenderer, "1-Click Preset (Pair w/ Sodium for 150+):", contentX + 8, winY + 52, 0xFFBBBBCC, false);

            String[] pNames = {"Ultra 150+", "Balanced", "Quality"};
            for (int[] pb : presetBounds) {
                boolean sel = (CrimsonGoldClient.CONFIG.fpsPreset == pb[4]);
                boolean hov = isHover(mouseX, mouseY, pb[0], pb[1], pb[2], pb[3]);
                drawRoundedBox(ctx, pb[0], pb[1], pb[2], pb[3], sel ? 0xCCE51A3C : (hov ? 0x882B121A : 0x66161118));
                drawRoundedOutline(ctx, pb[0], pb[1], pb[2], pb[3], sel ? 0xFFFFD466 : 0x44FFFFFF);
                ctx.drawCenteredTextWithShadow(this.textRenderer, pNames[pb[4] - 1], pb[0] + pb[2] / 2, pb[1] + 5, sel ? 0xFFFFFFFF : 0xFFCCCCCC);
            }
        }

        // Frosted Glass Module Cards
        for (ModCard c : visibleCards) {
            boolean on = c.getter().getAsBoolean();
            boolean hov = isHover(mouseX, mouseY, c.x(), c.y(), c.w(), c.h());
            int cardBg = on ? (hov ? 0xAA2B0F1A : 0x881F0B14) : (hov ? 0x881E1A22 : 0x66141118);
            drawRoundedBox(ctx, c.x(), c.y(), c.w(), c.h(), cardBg);
            drawRoundedOutline(ctx, c.x(), c.y(), c.w(), c.h(), hov ? 0xFFFFD466 : (on ? 0xAAE51A3C : 0x33FFFFFF));
            ctx.fill(c.x() + 2, c.y() + 1, c.x() + c.w() - 2, c.y() + 2, 0x2AFFFFFF); // Glass top shine

            ctx.drawTextWithShadow(this.textRenderer, c.name(), c.x() + 7, c.y() + 5, on ? 0xFFFFFFFF : 0xFFBBBBCC);
            ctx.drawText(this.textRenderer, c.desc(), c.x() + 7, c.y() + 18, 0xFF998EA3, false);

            int sw = 22, sh = 10;
            int sx = c.x() + c.w() - sw - 6;
            int sy = c.y() + (c.h() - sh) / 2;
            drawRoundedBox(ctx, sx, sy, sw, sh, on ? 0xFFE51A3C : 0xFF2C2632);
            int knobX = on ? (sx + sw - 8) : (sx + 2);
            ctx.fill(knobX, sy + 2, knobX + 6, sy + sh - 2, on ? 0xFFFFD466 : 0xFF9999AA);
        }

        if (totalPages > 1) {
            drawRoundedBox(ctx, prevX, prevY, navW, navH, page > 0 ? 0x8824141E : 0x44121018);
            ctx.drawCenteredTextWithShadow(this.textRenderer, "< Prev", prevX + navW / 2, prevY + 4, page > 0 ? 0xFFFFFFFF : 0xFF666677);
            String pgTxt = "Page " + (page + 1) + "/" + totalPages;
            ctx.drawCenteredTextWithShadow(this.textRenderer, pgTxt, (prevX + navW + nextX) / 2, prevY + 4, 0xFFCCCCCC);
            drawRoundedBox(ctx, nextX, nextY, navW, navH, page < totalPages - 1 ? 0x8824141E : 0x44121018);
            ctx.drawCenteredTextWithShadow(this.textRenderer, "Next >", nextX + navW / 2, nextY + 4, page < totalPages - 1 ? 0xFFFFFFFF : 0xFF666677);
        }
    }

    private void drawMiniCrown(DrawContext ctx, int x, int y) {
        int red = 0xFFE51A3C;
        int gold = 0xFFFFD466;
        ctx.fill(x, y, x + 2, y + 6, red);
        ctx.fill(x + 4, y - 1, x + 7, y + 6, red);
        ctx.fill(x + 9, y, x + 11, y + 6, red);
        ctx.fill(x, y + 4, x + 11, y + 8, red);
        ctx.fill(x + 1, y + 7, x + 10, y + 9, gold);
    }

    private boolean isHover(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void drawRoundedBox(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x + 2, y, x + w - 2, y + h, color);
        ctx.fill(x + 1, y + 1, x + 2, y + h - 1, color);
        ctx.fill(x + w - 2, y + 1, x + w - 1, y + h - 1, color);
        ctx.fill(x, y + 2, x + 1, y + h - 2, color);
        ctx.fill(x + w - 1, y + 2, x + w, y + h - 2, color);
    }

    private void drawRoundedOutline(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x + 2, y, x + w - 2, y + 1, color);
        ctx.fill(x + 2, y + h - 1, x + w - 2, y + h, color);
        ctx.fill(x, y + 2, x + 1, y + h - 2, color);
        ctx.fill(x + w - 1, y + 2, x + w, y + h - 2, color);
        ctx.fill(x + 1, y + 1, x + 2, y + 2, color);
        ctx.fill(x + w - 2, y + 1, x + w - 1, y + 2, color);
        ctx.fill(x + 1, y + h - 2, x + 2, y + h - 1, color);
        ctx.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, color);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
