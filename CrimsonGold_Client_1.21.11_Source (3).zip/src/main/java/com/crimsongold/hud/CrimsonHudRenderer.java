package com.crimsongold.hud;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;

public class CrimsonHudRenderer {
    private static float prevYaw = 0f;
    private static float prevPitch = 0f;
    private static float smoothBlur = 0f;

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        ClientConfig cfg = CrimsonGoldClient.CONFIG;
        if (cfg == null) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        if (cfg.motionBlurEnabled) {
            float yawDelta = Math.abs(mc.player.getYaw() - prevYaw);
            if (yawDelta > 180f) yawDelta = 360f - yawDelta;
            float pitchDelta = Math.abs(mc.player.getPitch() - prevPitch);
            float rawSpeed = Math.min(1.0f, (yawDelta + pitchDelta) / 14.0f);
            smoothBlur = smoothBlur * 0.78f + rawSpeed * 0.45f;
            if (smoothBlur > 0.02f) {
                int alpha = Math.min(120, (int) (smoothBlur * 85));
                int edgeW = Math.max(16, sw / 8);
                ctx.fill(0, 0, edgeW, sh, (alpha << 24) | 0x1A0A14);
                ctx.fill(sw - edgeW, 0, sw, sh, (alpha << 24) | 0x1A0A14);
            }
            prevYaw = mc.player.getYaw();
            prevPitch = mc.player.getPitch();
        }

        if (!cfg.hudEnabled) return;

        // Top-Left Crimson Glass Pill: FPS + XYZ + CPS + Reach
        if (cfg.cpsCounterEnabled) {
            String reachStr = (cfg.reachDisplayEnabled && System.currentTimeMillis() - CrimsonGoldClient.lastHitTimeMs < 3000L)
                    ? String.format("  §8|  §e%.2fm", CrimsonGoldClient.lastReachBlocks)
                    : "";
            String line = "§c♛ §f" + mc.getCurrentFps() + " FPS"
                    + String.format("  §8|  §6XYZ §f%d %d %d", (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ())
                    + "  §8|  §cCPS §f" + CrimsonGoldClient.getLeftCps() + "|" + CrimsonGoldClient.getRightCps()
                    + reachStr;

            int boxW = mc.textRenderer.getWidth(line) + 12;
            ctx.fill(7, 6, 7 + boxW - 2, 20, 0x880B080D);
            ctx.fill(6, 7, 7 + boxW - 1, 19, 0x880B080D);
            ctx.drawTextWithShadow(mc.textRenderer, line, 12, 9, 0xFFFFFFFF);
        }

        // Top-Right Ping & World Time Pill
        if (cfg.pingTimePillEnabled) {
            int ping = 0;
            if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null) {
                ping = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency();
            }
            String pt = "§6" + ping + "ms";
            int pw = mc.textRenderer.getWidth(pt) + 10;
            int px = sw - pw - 6;
            ctx.fill(px + 1, 6, px + pw - 1, 20, 0x880B080D);
            ctx.fill(px, 7, px + pw, 19, 0x880B080D);
            ctx.drawTextWithShadow(mc.textRenderer, pt, px + 5, 9, 0xFFFFFFFF);
        }

        // Custom Crimson Crosshair Accent
        boolean aimingAtEntity = mc.crosshairTarget instanceof EntityHitResult;
        if (cfg.crosshairEnabled) {
            int cx = sw / 2;
            int cy = sh / 2;
            int col = aimingAtEntity ? 0xFFFFD466 : 0xFFE51A3C;
            ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, col);
            if (aimingAtEntity) {
                ctx.fill(cx - 4, cy, cx - 2, cy + 1, col);
                ctx.fill(cx + 2, cy, cx + 4, cy + 1, col);
                ctx.fill(cx, cy - 4, cx + 1, cy - 2, col);
                ctx.fill(cx, cy + 2, cx + 1, cy + 4, col);
            }
        }

        // Tiny Mini Target Pill
        if (cfg.hitboxEnabled && aimingAtEntity && mc.crosshairTarget instanceof EntityHitResult ehr) {
            Entity target = ehr.getEntity();
            String hp = (target instanceof LivingEntity le)
                    ? String.format(" §c%.0f♥", le.getHealth())
                    : "";
            String txt = "§6" + target.getName().getString() + hp + String.format(" §7%.1fm", mc.player.distanceTo(target));
            int tw = mc.textRenderer.getWidth(txt) + 10;
            int tx = (sw - tw) / 2;
            ctx.fill(tx + 1, 6, tx + tw - 1, 20, 0x990C080E);
            ctx.fill(tx, 7, tx + tw, 19, 0x990C080E);
            ctx.drawTextWithShadow(mc.textRenderer, txt, tx + 5, 9, 0xFFFFFFFF);
        }

        // Keystrokes
        if (cfg.keystrokesEnabled) {
            int kx = 6;
            int ky = 25;
            drawKey(ctx, mc, kx + 20, ky, 18, 16, "W", mc.options.forwardKey.isPressed());
            drawKey(ctx, mc, kx, ky + 18, 18, 16, "A", mc.options.leftKey.isPressed());
            drawKey(ctx, mc, kx + 20, ky + 18, 18, 16, "S", mc.options.backKey.isPressed());
            drawKey(ctx, mc, kx + 40, ky + 18, 18, 16, "D", mc.options.rightKey.isPressed());
            drawKey(ctx, mc, kx, ky + 36, 28, 14, "LMB", mc.options.attackKey.isPressed());
            drawKey(ctx, mc, kx + 30, ky + 36, 28, 14, "RMB", mc.options.useKey.isPressed());
            drawKey(ctx, mc, kx, ky + 52, 58, 10, "---", mc.options.jumpKey.isPressed());
        }

        // Bottom-Left Sprint Pill
        if (cfg.sprintPillEnabled && cfg.toggleSprintEnabled) {
            String sp = mc.player.isSprinting() ? "§c♛ §a[Sprinting]" : "§c♛ §7[Sprint Ready]";
            int pw = mc.textRenderer.getWidth(sp) + 8;
            ctx.fill(6, sh - 18, 6 + pw, sh - 6, 0x880B080D);
            ctx.drawTextWithShadow(mc.textRenderer, sp, 10, sh - 16, 0xFFFFFFFF);
        }

        // Pro Horizontal Armor Durability Glass Card (Top-Right below Ping)
        if (cfg.armorHudEnabled) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            boolean hasAny = false;
            for (EquipmentSlot s : slots) {
                if (!mc.player.getEquippedStack(s).isEmpty()) { hasAny = true; break; }
            }
            if (hasAny) {
                int cardW = 86;
                int cardH = 26;
                int cardX = sw - cardW - 6;
                int cardY = 24;
                ctx.fill(cardX + 1, cardY, cardX + cardW - 1, cardY + cardH, 0x880B080D);
                ctx.fill(cardX, cardY + 1, cardX + cardW, cardY + cardH - 1, 0x880B080D);
                ctx.fill(cardX + 2, cardY, cardX + cardW - 2, cardY + 1, 0x88E51A3C);

                for (int i = 0; i < 4; i++) {
                    ItemStack stack = mc.player.getEquippedStack(slots[i]);
                    int ix = cardX + 4 + i * 20;
                    int iy = cardY + 3;
                    if (!stack.isEmpty()) {
                        ctx.drawItem(stack, ix, iy);
                        if (stack.isDamageable() && stack.getMaxDamage() > 0) {
                            float pct = 1.0f - (float) stack.getDamage() / stack.getMaxDamage();
                            int barW = Math.max(1, (int) (14 * pct));
                            int barCol = pct > 0.5f ? 0xFF44DD55 : (pct > 0.25f ? 0xFFFFD466 : 0xFFE51A3C);
                            ctx.fill(ix + 1, iy + 18, ix + 15, iy + 20, 0xFF221820);
                            ctx.fill(ix + 1, iy + 18, ix + 1 + barW, iy + 20, barCol);
                        }
                    }
                }
            }
        }
    }

    private static void drawKey(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, String label, boolean pressed) {
        int bg = pressed ? 0xCCE51A3C : 0x880B080D;
        int txtCol = pressed ? 0xFFFFD466 : 0xFFFFFFFF;
        ctx.fill(x + 1, y, x + w - 1, y + h, bg);
        ctx.fill(x, y + 1, x + w, y + h - 1, bg);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, txtCol, false);
    }
}
